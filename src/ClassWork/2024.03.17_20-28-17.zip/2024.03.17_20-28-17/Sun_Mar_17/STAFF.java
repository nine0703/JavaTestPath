package ClassWork.Sun_Mar_17;

public interface STAFF {
    void work();

}   // interface end.
