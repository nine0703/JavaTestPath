package ClassWork;

import ClassWork.Sun_Mar_17.Coder;
import ClassWork.Sun_Mar_17.Manager;

public class ClassWork {
    public static void main(String[] args) {
        Manager mg = new Manager("张三",123,15000,6000);
        mg.work();
        Coder cd = new Coder("李四",135,10000);
        cd.work();

    }   //  method main end.
}   // class end.
