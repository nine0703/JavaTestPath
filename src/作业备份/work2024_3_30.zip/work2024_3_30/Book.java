package work2024_3_30;

public class Book {
    // 书籍名称（name）、书籍作者（author）、出版年份（year）、书籍价格（price），存储至少2本书籍。
    private String author;
    private String name;
    private int year;
    private double price;

    public Book() {
    }

    public Book(String author, String name, int year, double price) {
        this.author = author;
        this.name = name;
        this.year = year;
        this.price = price;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "book{" +
                "author='" + author + '\'' +
                ", name='" + name + '\'' +
                ", year=" + year +
                ", price=" + price +
                '}';
    }
}   // Class end.
