package work2024_3_30;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BookControl {
    public static void main(String[] args) {
//    能够使用IDEA创建xml文件存储数据
//
//编写books.xml文件存书籍的数据，书籍信息包含： 书籍分类（category，书籍的属性）、
// 书籍名称（name）、书籍作者（author）、出版年份（year）、书籍价格（price），存储至少2本书籍。
        File f = new File("src/work2024_3_30/books.xml");
        ArrayList<Book> lib = new ArrayList<>();
        SAXReader saxReader = new SAXReader();
        if (f.exists() && f.length() != 0) {
            try {
                Document read = saxReader.read(f);
                Element rootElement = read.getRootElement();    // 源根
                List<Element> elements = rootElement.elements();    // 从源根获取的元素列表
                for (Element element : elements) {
                    String author = element.elementText("author");
                    String name = element.elementText("name");
                    int year = Integer.parseInt(element.elementText("year"));
                    double price = Double.parseDouble(element.elementText("price"));
                    lib.add(new Book(author, name, year, price));
                }
            } catch (DocumentException e) {
                throw new RuntimeException(e);
            }
        }
//        lib.add(new Book("hh", "nn", 2024, 56.12));
        for (Book book : lib) {
            System.out.println(book);
        }

        if (!f.exists()) {
            try {
                boolean newFile = f.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else {
            Document read = DocumentHelper.createDocument();    // 源根
            Element rootElement = read.addElement("books"); // 添加源根名称
            for (Book book : lib) {
                Element bookElement = rootElement.addElement("book");
                bookElement.addElement("name").addText(book.getName());
                bookElement.addElement("author").addText(book.getAuthor());
                bookElement.addElement("year").addText(String.valueOf(book.getYear()));
                bookElement.addElement("price").addText(String.valueOf(book.getPrice()));
            }
            try {
                XMLWriter writer = new XMLWriter(new FileWriter(f),new OutputFormat()); // 创建写入器，本来想换行的，不会
                writer.write(read); // 将文档写入文件
                writer.close(); // 关闭写入器
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }

    }   // Method main end.
}   // Class end.
