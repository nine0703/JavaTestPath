package work2024_3_30;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;


public class LoginController {
    public static void main(String[] args) {
//能力目标：能够读取properties文件数据
//要求:
//如果登陆成功要读取该用户的color属性的值.
//如果color=red 以红色字体把用户所有信息打印到控制台. // System.err.println(prop);
//如果color=black 以黑色字体把用户所有信息打印到控制台. // System.out.println(prop);
        File f = new File("src/work2024_3_30/config.properties");
        if (!f.exists()) {
            System.out.println("file not exists.");
            System.exit(0);
        }
        Properties prop = new Properties();
        try {
            prop.load(new FileInputStream(f));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }   // load complete.

        Scanner sc = new Scanner(System.in);
        boolean login = false;
        while (true) {
            System.out.println("开始输入账户：");
            String username = sc.nextLine();
            System.out.println("开始输入密码：");
            String passwd = sc.nextLine();
            if (username.equals(prop.getProperty("username")) && passwd.equals(prop.getProperty("password"))){
                System.out.println("logined.");
                login = true;
                break;
            }else {
                System.out.println("login failed.");
            }
        }

        if (prop.getProperty("color").equals("red")) {
            System.err.println(prop);
        } else if (prop.getProperty("color").equals("black")) {
            System.out.println(prop);
        } else {
            System.out.println("unkown color");
            throw new RuntimeException();
        }


    }   // Method main end.

}   // Class end.
