# 注意！！！全部作业均由本人独立完成，只有readme文件的生成使用了ChatGPT

# LoginController

这个Java程序用于读取properties文件中的用户信息，并根据用户的登录情况和颜色设置打印用户信息到控制台。

## 功能

- 从配置文件中读取用户信息和颜色设置。
- 提供登录界面，允许用户输入用户名和密码进行登录。
- 根据用户登录情况和颜色设置，打印用户信息到控制台。

## 使用方法

1. 确保存在名为`config.properties`的配置文件，其中包含以下信息：
    - `username`: 用户名
    - `password`: 密码
    - `color`: 文字颜色设置，可选值为`red`或`black`

2. 运行`LoginController.java`文件。
3. 按照提示输入用户名和密码进行登录。
4. 根据配置文件中的颜色设置，查看打印到控制台的用户信息。

## 文件结构

- `LoginController.java`: 主程序文件，包含主要的登录逻辑。
- `config.properties`: 配置文件，包含用户信息和颜色设置。

## 注意事项

- 确保配置文件`config.properties`的路径正确，并且包含了必要的信息。
- 确保配置文件中的颜色设置为`red`或`black`之一，否则会抛出异常。

**此Readme文件由ChatGPT一键生成。版权所有 © 2024 [Java餐饮]**

**Update Sat Mar 30 21:19:30 CST 2024**
