package work2024_3_30;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class BookControllter {
    public static void main(String[] args) {
        List<Book> lib = new ArrayList<>();
        File f = new File("src/work2024_3_30/book.xml");
        if (f.exists()) {
            SAXReader saxReader = new SAXReader();
            try {
                Document read = saxReader.read(f);
                Element rootElement = read.getRootElement();
                List<Element> elements = rootElement.elements();
                for (Element element : elements) {
                    String category = element.attributeValue("category");
                    String name = element.elementText("name");
                    String author = element.elementText("author");
                    int year = Integer.parseInt(element.elementText("year"));
                    double price = Double.parseDouble(element.elementText("price"));
                    lib.add(new Book(category, name, author, year, price));
                }
            } catch (DocumentException e) {
                throw new RuntimeException(e);
            }
        }
        for (Book book : lib) {
            System.out.println(book);
        }


    }   // Method main end.

}   // Class end.
