# BookControl

这个Java程序用于创建和操作XML文件来存储书籍信息。它使用了dom4j库来处理XML文件的读取和写入。

## 功能

- 创建一个XML文件用于存储书籍信息。
- 将书籍信息从XML文件读取到程序中。
- 将新的书籍信息添加到XML文件中。

## 使用方法

1. 下载并安装Java Development Kit (JDK)。
2. 使用任何Java集成开发环境（如IntelliJ IDEA）打开项目。
3. 运行`BookControl.java`文件。
4. 检查`books.xml`文件以查看书籍信息。

## 文件结构

- `BookControl.java`: 主程序文件，包含主要的书籍控制逻辑。
- `Book.java`: 书籍类，用于表示书籍信息。
- `books.xml`: XML文件，用于存储书籍信息。

## 书籍信息格式

每本书籍包含以下信息：

- 书籍名称（name）
- 书籍作者（author）
- 出版年份（year）
- 书籍价格（price）

## 注意事项

- 如果`books.xml`文件不存在，程序将自动创建该文件。
- 请确保`books.xml`文件的编码格式为UTF-8，以避免读取和写入中文字符时出现问题。


**此Readme文件由ChatGPT一键生成。版权所有 © 2024 [Java餐饮]**

**Update Sat Mar 30 21:19:30 CST 2024**
